'use client';

import dynamic from 'next/dynamic';
import Navigation from '@/components/portfolio/Navigation';
import Hero from '@/components/portfolio/Hero';
import Ticker from '@/components/portfolio/Ticker';
import VideoIntro from '@/components/VideoIntro/VideoIntro';
import About from '@/components/portfolio/About';
import Experience from '@/components/portfolio/Experience';
import Skills from '@/components/portfolio/Skills';
import Projects from '@/components/portfolio/Projects';
import AIChat from '@/components/portfolio/AIChat';
import Contact from '@/components/portfolio/Contact';
import Footer from '@/components/portfolio/Footer';

const ParticleBackground = dynamic(() => import('@/components/portfolio/ParticleBackground'), {
  ssr: false,
});

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-[#0A0603] text-[#FFF3E2] overflow-x-hidden">
      {/* Background gradient overlay — amber/cyan glows */}
      <div
        className="fixed inset-0 pointer-events-none z-0"
        style={{
          background:
            'radial-gradient(ellipse 80% 60% at 15% 5%, rgba(245, 168, 50, 0.08) 0%, transparent 60%), radial-gradient(ellipse 60% 50% at 85% 75%, rgba(0, 200, 220, 0.06) 0%, transparent 55%), radial-gradient(ellipse 50% 40% at 50% 50%, rgba(212, 137, 26, 0.03) 0%, transparent 50%)',
        }}
      />

      {/* Grid overlay pattern */}
      <div
        className="fixed inset-0 pointer-events-none z-[1] grid-overlay"
      />

      {/* Three.js particle background */}
      <ParticleBackground />

      {/* Navigation */}
      <Navigation />

      {/* Cinematic Video Hero */}
      <VideoIntro />

      {/* Main content */}
      <main id="main-content" className="flex-1 relative z-10" style={{ scrollMarginTop: '0px' }}>
        <Hero />
        <Ticker />
        <div id="about-anchor" style={{ scrollMarginTop: '80px' }}>
          <About />
        </div>
        <Experience />
        <Skills />
        <Projects />
        <AIChat />
        <Contact />
      </main>

      <Footer />
    </div>
  );
}
